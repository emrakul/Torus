#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *textFileRead(char *fn);
int textFileWrite(char *fn, char *s);



