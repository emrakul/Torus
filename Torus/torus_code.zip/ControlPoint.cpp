#include "ControlPoint.h"


ControlPoint::ControlPoint()
{
}





ControlPoint::~ControlPoint()
{
}
